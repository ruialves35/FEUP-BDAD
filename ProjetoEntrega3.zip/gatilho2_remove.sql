drop trigger if exists EpisodioApagado;
drop trigger if exists TemporadaApagada;