-- Deve atualizar os tuplos em vez de dar erro

select * from FilmeQualidade;

insert into FilmeQualidade values(2, 1080, "www.umfilmebacano.com");

select * from FilmeQualidade;


select * from ConteudoEspecialQualidade;

insert into ConteudoEspecialQualidade values(4, 2160, "www.umconteudospecialcom");

select * from ConteudoEspecialQualidade;


select * from EpisodioQualidade;

insert into EpisodioQualidade values(2, 720, "www.wintertube.com");

select * from EpisodioQualidade;