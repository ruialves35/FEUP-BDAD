drop trigger if exists FavoritoNoHistorico;
drop trigger if exists RecomendadoNaoVisto;