drop trigger if exists FilmeQualidadeRepetido;
drop trigger if exists ConteudoEspecialQualidadeRepetido;
drop trigger if exists EpisodioQualidadeRepetido;